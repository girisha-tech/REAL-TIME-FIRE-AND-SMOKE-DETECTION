import cv2
import numpy as np
import winsound
cap = cv2.VideoCapture(0)
lower_fire = np.array([10, 100, 100])   
upper_fire = np.array([30, 255, 255])   

fire_detected_count = 0
threshold = 5  
while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame = cv2.resize(frame, (640, 480))
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lower_fire, upper_fire)
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=4)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    fire_found = False
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > 1500:  
            fire_found = True
            x, y, w, h = cv2.boundingRect(cnt)
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 2)
            cv2.putText(frame, "FIRE DETECTED", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    
    if fire_found:
        fire_detected_count += 1
    else:
        fire_detected_count = max(0, fire_detected_count - 1)
    if fire_detected_count >= threshold:
        winsound.PlaySound("firealarm.wav", winsound.SND_FILENAME)
        fire_detected_count = 0  
    cv2.imshow("Fire Detection", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()